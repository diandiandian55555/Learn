#pragma once

#define ADMIN_FILE   "admin.txt"

#define STUDENT_FILE  "student.txt"

#define TEACHER_FILE  "teacher.txt"

#define COMPUTER_FILE  "computer.txt"

#define  ORDER_FILE  "order.txt"
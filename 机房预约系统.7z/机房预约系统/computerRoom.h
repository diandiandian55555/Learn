#pragma once
#include<iostream>
using namespace std;

class computerRoom {
public:
	int m_comId;
	int m_maxNum;
};
